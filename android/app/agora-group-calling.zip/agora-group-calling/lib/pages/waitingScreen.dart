//import 'package:agora_video_call/pages/CallPage.dart';
//import 'package:cloud_firestore/cloud_firestore.dart';
//import 'package:flutter/cupertino.dart';
//import 'package:flutter/material.dart';
//import 'package:permission_handler/permission_handler.dart';
//
//class waitingScreen extends StatefulWidget {
//  @override
//  State<StatefulWidget> createState() {
//    // TODO: implement createState
//    return _waitingState();
//  }
//}
//
//class _waitingState extends State<waitingScreen> {
//  String ourChannelName = '';
//
//  @override
//  Widget build(BuildContext context) {
//    // TODO: implement build
//    return StreamBuilder<DocumentSnapshot>(
//        stream: FirebaseFirestore.instance
//            .collection('CallDetails')
//            .doc('live')
//            .snapshots(),
//        builder: (context, snap) {
//          if (snap.hasData) {
//            DocumentSnapshot ss = snap.data;
//            Map<String, dynamic> details = ss.data();
//            if (ourChannelName != '')
//              ourChannelName = 'randomCall${details.length}';
//            if (details.length != 0) {
//              details.forEach((key, value) {
//                if (key != ourChannelName && value == 'waiting') {
//                  onJoin(value);
//                } else if (key == ourChannelName && value == 'joining') {
//                  onJoin(value);
//                } else {
//                  addToFirestore(ourChannelName, 'waiting');
//                }
//              });
//            } else {}
//          }
//          return Center(
//            child: Column(
//              mainAxisAlignment: MainAxisAlignment.center,
//              crossAxisAlignment: CrossAxisAlignment.center,
//              children: [
//                CircularProgressIndicator(),
//                SizedBox(
//                  height: 20,
//                ),
//                Text('Looking for users...'),
//              ],
//            ),
//          );
//        });
//  }
//
//  Future<void> addToFirestore(String key, String val) {
//    FirebaseFirestore.instance
//        .collection('CallDetails')
//        .doc('live')
//        .update({key: val});
//  }
//
//  Future<void> onJoin(String channelName) async {
//    await _handleCameraAndMic(Permission.camera);
//    await _handleCameraAndMic(Permission.microphone);
//    addToFirestore(channelName, 'joining');
//    Navigator.push(
//      context,
//      MaterialPageRoute(
//        builder: (context) => CallPage(channelName: channelName),
//      ),
//    );
//  }
//
//  Future<void> _handleCameraAndMic(Permission permission) async {
//    final status = await permission.request();
//    print(status);
//  }
//}
